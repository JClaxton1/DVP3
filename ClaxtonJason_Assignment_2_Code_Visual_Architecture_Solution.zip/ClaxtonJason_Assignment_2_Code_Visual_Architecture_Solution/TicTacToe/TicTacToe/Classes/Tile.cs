﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace TicTacToe
{
    public enum TileType
    {
        None,
        X,
        O
    }

    public class Tile
    {
        private TileType tileType;
        public Bitmap Image { get; set; }

        public TileType TileType
        {
            get { return tileType; }
            set
            {
                tileType = value;
                SetTileImage();
            }
        }

        public Tile(TileType type)
        {
            this.tileType = type;
            SetTileImage();
        }

        private void SetTileImage()
        {
            if (tileType == TileType.X)
            {
                Image = new Bitmap("X.png");
            }
            else if (tileType == TileType.O)
            {
                Image = new Bitmap("O.png");
            }
            else
            {
                Image = new Bitmap("none.png");
            }
        }
    }
}
