﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        private TileType currentType;
        private Tile[,] board;
        private int size;
        private bool hasWinner = false;

        public Form1()
        {
            InitializeComponent();
            size = 3;
            ResetBoard();
        }

        private void ResetBoard()
        {
            board = new Tile[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    board[i, j] = new Tile(TileType.None);
                }
            }
            currentType = TileType.X;
            rdoX.Checked = true;
            rdoO.Checked = false;
            rdoX.Visible = rdoO.Visible = true;
            lblSelectTile.Visible = true;
            lblMessage.Visible = false;
            hasWinner = false;
            DrawBoard();
        }

        private void DrawBoard()
        {
            Bitmap gameImage = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics g = Graphics.FromImage(gameImage);
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    g.DrawImage(board[i, j].Image, 100 * i + 1, 100 * j + 1);
                }
            }
            pictureBox1.Image = gameImage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ResetBoard();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            DrawBoard();
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (hasWinner) return;
            HideOptions();
            int x = e.X / 100;
            int y = e.Y / 100;

            if (board[x, y].TileType == TileType.None)
            {
                board[x, y].TileType = currentType;
                FlipCurrentType();
                DrawBoard();
                CheckWinner();
            }
        }

        private void CheckWinner()
        {
            Boolean isEqual = false;
            TileType lastType = TileType.None;

            //vertical
            for (int i = 0; i < size; i++)
            {
                isEqual = true;
                lastType = TileType.None;
                for (int j = 0; j < size - 1; j++)
                {
                    lastType = board[i, j + 1].TileType;
                    if (board[i, j].TileType != board[i, j + 1].TileType)
                    {
                        isEqual = false;
                        break;
                    }
                }
                if (isEqual && lastType != TileType.None)
                {
                    ShowWinnerMessage(lastType.ToString());
                    return;
                }
            }

            //horizontal
            for (int i = 0; i < size; i++)
            {
                isEqual = true;
                lastType = TileType.None;
                for (int j = 0; j < size - 1; j++)
                {
                    lastType = board[j + 1, i].TileType;
                    if (board[j, i].TileType != board[j + 1, i].TileType)
                    {
                        isEqual = false;
                        break;
                    }
                }
                if (isEqual && lastType != TileType.None)
                {
                    ShowWinnerMessage(lastType.ToString());
                    return;
                }
            }

            //diagonal
            isEqual = true;
            lastType = TileType.None;
            for (int i = 0; i < size - 1; i++)
            {
                lastType = board[i + 1, i + 1].TileType;
                if (board[i, i].TileType != board[i + 1, i + 1].TileType)
                {
                    isEqual = false;
                    break;
                }
            }

            if (isEqual && lastType != TileType.None)
            {
                ShowWinnerMessage(lastType.ToString());
                return;
            }

            isEqual = true;
            lastType = TileType.None;
            for (int i = size - 1; i > 0; i--)
            {
                lastType = board[i - 1, size - i].TileType;
                if (board[i, size - i - 1].TileType != board[i - 1, size - i].TileType)
                {
                    isEqual = false;
                    break;
                }
            }

            if (isEqual && lastType != TileType.None)
            {
                ShowWinnerMessage(lastType.ToString());
                return;
            }
        }

        private void ShowWinnerMessage(String winner)
        {
            lblMessage.Visible = true;
            //lblMessage.Text = String.Format("The winner is {0}", winner);
            lblMessage.Text = "Three in a row, you have won!";
            hasWinner = true;
        }

        private void rdoX_CheckedChanged(object sender, EventArgs e)
        {
            currentType = TileType.X;
        }

        private void rdoO_CheckedChanged(object sender, EventArgs e)
        {
            currentType = TileType.O;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            HideOptions();
        }

        private void HideOptions()
        {
            rdoX.Visible = rdoO.Visible = false;
            lblSelectTile.Visible = false;
        }

        private void FlipCurrentType()
        {
            if (currentType == TileType.O)
            {
                currentType = TileType.X;
            }
            else
            {
                currentType = TileType.O;
            }
        }
    }
}
