﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rdoX = new System.Windows.Forms.RadioButton();
            this.rdoO = new System.Windows.Forms.RadioButton();
            this.lblSelectTile = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(37, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(324, 308);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(127, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 39);
            this.button1.TabIndex = 1;
            this.button1.Text = "Start New Game";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rdoX
            // 
            this.rdoX.AutoSize = true;
            this.rdoX.Checked = true;
            this.rdoX.Location = new System.Drawing.Point(172, 74);
            this.rdoX.Name = "rdoX";
            this.rdoX.Size = new System.Drawing.Size(32, 17);
            this.rdoX.TabIndex = 2;
            this.rdoX.TabStop = true;
            this.rdoX.Text = "X";
            this.rdoX.UseVisualStyleBackColor = true;
            this.rdoX.CheckedChanged += new System.EventHandler(this.rdoX_CheckedChanged);
            // 
            // rdoO
            // 
            this.rdoO.AutoSize = true;
            this.rdoO.Location = new System.Drawing.Point(210, 74);
            this.rdoO.Name = "rdoO";
            this.rdoO.Size = new System.Drawing.Size(33, 17);
            this.rdoO.TabIndex = 2;
            this.rdoO.Text = "O";
            this.rdoO.UseVisualStyleBackColor = true;
            this.rdoO.CheckedChanged += new System.EventHandler(this.rdoO_CheckedChanged);
            // 
            // lblSelectTile
            // 
            this.lblSelectTile.AutoSize = true;
            this.lblSelectTile.Location = new System.Drawing.Point(67, 76);
            this.lblSelectTile.Name = "lblSelectTile";
            this.lblSelectTile.Size = new System.Drawing.Size(99, 13);
            this.lblSelectTile.TabIndex = 3;
            this.lblSelectTile.Text = "Select Starting Tile:";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(124, 58);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(87, 13);
            this.lblMessage.TabIndex = 3;
            this.lblMessage.Text = "Winner Message";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 415);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblSelectTile);
            this.Controls.Add(this.rdoO);
            this.Controls.Add(this.rdoX);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Tic Tac Toe Game";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rdoX;
        private System.Windows.Forms.RadioButton rdoO;
        private System.Windows.Forms.Label lblSelectTile;
        private System.Windows.Forms.Label lblMessage;
    }
}

