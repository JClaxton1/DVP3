﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    public class Contact
    {
        private Guid id;

        public Guid Id
        {
            get { return id; }
        }

        public String FirstName
        {
            get; set;
        }

        public String LastName
        {
            get; set;
        }

        public String PhoneNumber
        {
            get; set;
        }

        public String Email
        {
            get; set;
        }

        public override string ToString()
        {
            return String.Format("{0} {1}", FirstName, LastName);
        }

        public Contact()
        {
            id = Guid.NewGuid();
        }
    }
}
