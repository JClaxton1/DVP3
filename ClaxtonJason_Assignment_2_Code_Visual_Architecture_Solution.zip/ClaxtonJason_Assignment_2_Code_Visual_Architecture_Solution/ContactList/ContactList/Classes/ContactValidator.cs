﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactList
{
    public class ContactValidator
    {
        public Boolean ValidateContact(String firstName, String lastName, String phoneNumber, String email, out List<String> messages)
        {
            Boolean valid = true;
            messages = new List<string>();
            messages.Add("Please correct the following before adding a new contact:");
            messages.Add("");

            //first name
            if (firstName.Length == 0)
            {
                valid = false;
                messages.Add("Invalid First Name.");
            }

            //last name
            if (lastName.Length == 0)
            {
                valid = false;
                messages.Add("Invalid Last Name.");
            }

            //phone Number
            if(phoneNumber.Length < 10)
            {
                valid = false;
                messages.Add("Phone Number must be at least of 10 digits.");
            }

            //email
            if(email.Length == 0 || !IsValidEmail(email))
            {
                valid = false;
                messages.Add("Email Id is not in correct format.");
            }

            return valid;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
    }
}
