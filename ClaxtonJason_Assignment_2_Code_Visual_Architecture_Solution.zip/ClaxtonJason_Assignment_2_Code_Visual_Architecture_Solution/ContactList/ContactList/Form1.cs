﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;

namespace ContactList
{
    public partial class Form1 : Form
    {
        private List<Contact> _contacts;

        public Form1()
        {
            InitializeComponent();
            _contacts = new List<Contact>();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ContactValidator validator = new ContactValidator();
            List<String> messages = new List<string>();
            if (validator.ValidateContact(
                txtFirstName.Text,
                txtLastName.Text,
                txtPhoneNumber.Text,
                txtEmail.Text, out messages)
            )
            {
                _contacts.Add(new Contact()
                {
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    PhoneNumber = txtPhoneNumber.Text.Trim(),
                    Email = txtEmail.Text.Trim()
                });
                txtErrors.Text = "";
                RefreshList();
            }
            else
            {
                string errorText = String.Join("\r\n", messages);
                txtErrors.Text = errorText;
            }
        }

        private void RefreshList()
        {
            int selectedIdx = -1;
            if (listContacts.SelectedIndices.Count > 0)
            {
                selectedIdx = listContacts.SelectedIndices[0];
            }

            listContacts.Items.Clear();
            ListViewItem item;
            _contacts.ForEach(contact =>
            {
                item = new ListViewItem(contact.ToString());
                item.Tag = contact;
                item.ImageIndex = 0;
                listContacts.Items.Add(item);
            });

            if (listContacts.Items.Count > 0)
            {
                if (selectedIdx <= _contacts.Count - 1 && selectedIdx > -1)
                {
                    listContacts.Items[selectedIdx].Selected = true;
                }
                else
                {
                    listContacts.Items[0].Selected = true;
                }
            }
        }

        private void btnSmall_Click(object sender, EventArgs e)
        {
            listContacts.View = View.SmallIcon;
        }

        private void btnLarge_Click(object sender, EventArgs e)
        {
            listContacts.View = View.LargeIcon;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (listContacts.SelectedItems.Count == 0) return;
            Contact contact = listContacts.SelectedItems[0].Tag as Contact;

            XmlSerializer serializer = new XmlSerializer(typeof(Contact));
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Xml files(*.xml) | *.xml;";
            sfd.FilterIndex = 1;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                FileStream stream = new FileStream(sfd.FileName, FileMode.CreateNew);
                serializer.Serialize(stream, contact);
            }
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Contact contact;
            XmlSerializer serializer = new XmlSerializer(typeof(Contact));
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Xml files(*.xml) | *.xml;";
            ofd.FilterIndex = 1;
            ofd.Multiselect = false;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                contact = (Contact)serializer.Deserialize(new FileStream(ofd.FileName, FileMode.Open));
                _contacts.Add(contact);
                RefreshList();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (listContacts.SelectedItems.Count == 0) return;
            Contact contact = listContacts.SelectedItems[0].Tag as Contact;

            EditContact editContactForm = new EditContact(contact);
            editContactForm.ShowDialog();
            RefreshList();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listContacts.SelectedItems.Count == 0) return;
            Contact contact = listContacts.SelectedItems[0].Tag as Contact;
            _contacts.RemoveAll(c => c.Id == contact.Id);
            RefreshList();
        }
    }
}
