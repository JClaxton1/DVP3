﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactList
{
    public partial class EditContact : Form
    {
        Contact _contact;
        public EditContact(Contact contact)
        {
            InitializeComponent();

            _contact = contact;
            txtFirstName.Text = _contact.FirstName;
            txtLastName.Text = _contact.LastName;
            txtPhoneNumber.Text = _contact.PhoneNumber.ToString();
            txtEmail.Text = _contact.Email;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ContactValidator validator = new ContactValidator();
            List<String> messages = new List<string>();
            if (validator.ValidateContact(
                txtFirstName.Text,
                txtLastName.Text,
                txtPhoneNumber.Text,
                txtEmail.Text, out messages)
            )
            {
                _contact.FirstName = txtFirstName.Text.Trim();
                _contact.LastName = txtLastName.Text.Trim();
                _contact.PhoneNumber = txtPhoneNumber.Text.Trim();
                _contact.Email = txtEmail.Text.Trim();
                txtErrors.Text = "";
                this.Close();
            }
            else
            {
                string errorText = String.Join("\r\n", messages);
                txtErrors.Text = errorText;
            }                        
        }
    }
}
