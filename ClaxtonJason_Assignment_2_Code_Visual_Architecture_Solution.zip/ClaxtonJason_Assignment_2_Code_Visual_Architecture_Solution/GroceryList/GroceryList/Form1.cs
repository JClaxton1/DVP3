﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace GroceryList
{
    public partial class Form1 : Form
    {
        private List<GroceryItem> _items;

        public Form1()
        {
            InitializeComponent();
            _items = new List<GroceryItem>();
        }

        private void RefreshList()
        {
            int selectedIdx = -1;
            if (lstItems.SelectedIndices.Count > 0)
            {
                selectedIdx = lstItems.SelectedIndices[0];
            }
            lstItems.Items.Clear();
            _items.ForEach(item =>
            {
                ListViewItem item1 = new ListViewItem();
                item1.Tag = item;
                if (item.Type == ItemType.Want)
                {
                    item1.Text = item.Name;
                    item1.SubItems.Add("");
                }
                else
                {
                    item1.Text = "";
                    item1.SubItems.Add(item.Name);
                }

                lstItems.Items.Add(item1);
            });

            if (lstItems.Items.Count > 0)
            {
                if (selectedIdx <= _items.Count - 1 && selectedIdx > -1)
                {
                    lstItems.Items[selectedIdx].Selected = true;
                }
                else
                {
                    lstItems.Items[0].Selected = true;
                }
            }
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            _items.Add(new GroceryItem()
            {
                Name = txtItemName.Text,
                Type = (rdoWant.Checked) ? ItemType.Want : ItemType.Need
            });
            txtItemName.Text = "";
            RefreshList();
        }

        private void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstItems.SelectedItems.Count == 0) return;
            GroceryItem item = lstItems.SelectedItems[0].Tag as GroceryItem;

            if (item.Type == ItemType.Want)
            {
                btnMove.Text = "Move To Need";
            }
            else
            {
                btnMove.Text = "Move To Want";
            }
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            if (lstItems.SelectedItems.Count == 0) return;

            GroceryItem item = lstItems.SelectedItems[0].Tag as GroceryItem;
            item.FlipType();
            RefreshList();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstItems.SelectedItems.Count == 0) return;
            GroceryItem item = lstItems.SelectedItems[0].Tag as GroceryItem;
            Guid selectedId = item.Id;
            _items.RemoveAll(i => i.Id == selectedId);
            RefreshList();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<GroceryItem>));
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Xml files(*.xml) | *.xml;";
            sfd.FilterIndex = 1;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                FileStream stream = new FileStream(sfd.FileName, FileMode.CreateNew);
                serializer.Serialize(stream, _items);
            }
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<GroceryItem>));
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Xml files(*.xml) | *.xml;";
            ofd.FilterIndex = 1;
            ofd.Multiselect = false;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _items = (List<GroceryItem>)serializer.Deserialize(new FileStream(ofd.FileName, FileMode.Open));
                RefreshList();
            }
        }
    }
}
