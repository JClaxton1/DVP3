﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroceryList
{
    public enum ItemType
    {
        Want,
        Need
    }

    public class GroceryItem
    {
        public String Name { get; set; }
        public ItemType Type { get; set; }
        private Guid id;

        public Guid Id { get { return id; } }

        public GroceryItem()
        {
            id = Guid.NewGuid();
        }

        public void FlipType()
        {
            if(Type == ItemType.Want)
            {
                Type = ItemType.Need;
            }
            else
            {
                Type = ItemType.Want;
            }
        }
    }
}
